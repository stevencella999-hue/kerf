# Kerf

A free, open-source, browser-based image prep tool for laser engraving.
Upload a photo, pick a material, download an engraving-ready file — all
processing happens locally in your browser, no image is ever uploaded
anywhere.

Inspired by the workflow of paid tools like imagR's "One Click" preparation
page, built from scratch as an independent open-source project (no code,
assets, or branding shared with any commercial product).

## Features

- **10 material presets** (wood, black slate, acrylic, leather, cork, glass,
  anodized aluminum, stainless steel, white tile, white tile painted black),
  each with its own tone curve and mark polarity (some materials need an
  inverted image, e.g. slate/aluminum/painted tile where the laser removes a
  dark coating to reveal a light substrate).
- **DPI-based sizing** — set physical width/height + DPI and the app computes
  exact pixel dimensions.
- **Four dithering modes** — Floyd–Steinberg, Atkinson, ordered (8×8 Bayer),
  or disabled (hard threshold).
- **Laser presets** for CO2, Diode, Fiber, Galvo, and UV lasers, with
  material-adjusted starting speed/power/frequency/pulse values you can
  fine-tune.
- **Four export formats** — PNG, 24-bit BMP, 1-bit BMP, and a LightBurn
  `.lbrn2` project file with your cut settings pre-filled.
- **Batch mode** — process multiple images against the same material/laser
  settings in one pass.
- **Before/after compare slider** and a live preview before you download.
- Zero backend, zero build step, zero dependencies — open `index.html` and go.

## Getting started

No build tooling required.

```bash
git clone <this-repo-url>
cd kerf
python3 -m http.server 8000   # or any static file server
# open http://localhost:8000
```

Or just open `index.html` directly in a modern browser (Chrome, Firefox,
Edge, Safari) — everything runs client-side with the Canvas API.

## How it works

1. **Upload** an image (PNG/JPG/WEBP), single or batch.
2. **Pick a material** — this sets a tone curve (brightness/contrast/gamma)
   and, where needed, inverts the image so the *mark* reads correctly on that
   material.
3. **Set size, DPI, and dithering** — the image is resized to the exact pixel
   dimensions your laser needs, converted to grayscale with the material's
   tone curve applied, then dithered to 1-bit black/white (or left
   continuous-tone if dithering is disabled).
4. **Pick a laser type** to populate starting speed/power/frequency values,
   adjust them, and **download** in whichever format your software expects.

All of this — resizing, grayscale conversion, tone curves, dithering, and
file encoding — happens in `js/imaging.js`, `js/dither.js`, and
`js/export.js`. No network calls, no analytics, no image ever leaves the
page.

## Project structure

```
index.html            Markup / layout
css/style.css          Styling
js/materials.js        Material tone-curve presets
js/laser-presets.js    Laser type + material speed/power defaults
js/dither.js           Dithering algorithms (Floyd–Steinberg, Atkinson, ordered, threshold)
js/imaging.js           Resize + tone curve + pipeline orchestration
js/export.js            PNG / BMP24 / BMP1 / LightBurn .lbrn2 encoders
js/app.js               UI wiring
```

## A few honest caveats

- **Material and laser presets are starting points**, not a physical
  simulation of any real machine. Burn results vary by laser, lens, power
  supply, and even the specific batch of material. Always test on scrap
  before committing to a final piece.
- **The `.lbrn2` export is a best-effort minimal project file.** LightBurn's
  project format isn't fully publicly documented, so this covers the common
  case (one bitmap shape + one cut setting) but hasn't been verified against
  every LightBurn version. Open an issue (or a PR) if you find an import
  problem.
- The 1-bit BMP encoder was validated against Pillow and ImageMagick; some
  lightweight image viewers/libraries (including some in-browser BMP
  decoders) don't support 1-bit BMP at all — that's a limitation of the
  target software, not the file.

## Contributing

Issues and PRs welcome — additional material presets, better tone curves for
specific machines, a real `.lbrn2` schema validated against LightBurn's
source, or additional export formats (e.g. `.nc`/G-code) are all good
places to start.

## License

MIT — see [LICENSE](LICENSE).
